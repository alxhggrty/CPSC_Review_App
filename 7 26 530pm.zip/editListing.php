<?php
  session_start();
  require_once("db.php");
  if(isset($_SESSION["recall_ID"])) $recall_ID = $_SESSION["recall_ID"];
  if(isset($_SESSION["recall_Number"])) $recall_Number = $_SESSION["recall_Number"];
  $err=false;
  $sql="select * from recall where recall_ID='$recall_ID' and recall_Number='$recall_Number'";
  $result = $mydb->query($sql);
  while($row=mysqli_fetch_array($result)){
    $recall_ID=$row['recall_ID'];
    $recall_Number=$row['recall_Number'];
    $recall_date=$row['recall_date'];
    $recall_Description=$row['recall_Description'];
    $recall_title=$row['recall_title'];
    $recall_Last_Publish_Date=$row['recall_Last_Publish_Date'];
    $recall_Product_Name=$row['recall_Product_Name'];
    $recall_URL=$row['recall_URL'];

  }
  if (isset($_POST["submit"])) {


    if (!empty($recall_Number) && !empty($recall_date) && !empty($recall_Last_Publish_Date)
        && !empty($recall_ID) && !empty($recall_Description)&& !empty($recall_Product_Name)&& !empty($recall_URL))
    {
     if(isset($_POST["recall_ID"])) $_SESSION["recall_ID"] = $_POST["recall_ID"];
      if(isset($_POST["recall_Number"])) $_SESSION["recall_Number"] = $_POST["recall_Number"];
      if(isset($_POST["recall_date"])) $_SESSION["recall_date"] = $_POST["recall_date"];
      if(isset($_POST["recall_Description"])) $_SESSION["recall_Description"] = $_POST["recall_Description"];
      if(isset($_POST["recall_title"])) $_SESSION["recall_title"] = $_POST["recall_title"];
      if(isset($_POST["recall_Last_Publish_Date"])) $_SESSION["recall_Last_Publish_Date"] = $_POST["recall_Last_Publish_Date"];
      if(isset($_POST["recall_Product_Name"])) $_SESSION["recall_Product_Name"] = $_POST["recall_Product_Name"];
      if(isset($_POST["recall_URL"])) $_SESSION["recall_URL"] = $_POST["recall_URL"];
      header("Location: editListingConfirm.php");
    }
    else
    {
      $err = true;
    }
  }
?>

<!doctype html>
<html>
<script>document.getElementById('datePicker').value = new Date().toDateInputValue();
</script>
<head>
  <title>CPSC RECALLS</title>

   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
   <link rel="stylesheet" href="stylesheet.css" />
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
  <img src="CPSCLOGO.png" height=5% width=5% />
  <ul class="nav nav-tabs">
  <li><a href="clientLanding.php">Home</a></li>
  <li class="active"><a href="clientListingsPage.php">Recalls</a></li>
  <li><a href="clientCurrentLoads.php">Potential Violations</a></li>
  <li><a href="clientPastLoads.php">Processed Potential Violations</a></li>
  <li><a href="createListing.php">Add Recalls</a></li>
  <li><a href="clientAccountManagement.php">Manage Account</a></li>
</ul>
      <div style='margin-left: auto; display: block; margin-right: auto;width: 800px;'>
      ENTER NEW RECALL INFORMATION
    </br>
  </br>
  <form method="post" action="<?php echo $_SERVER['PHP_SELF']?>">
    <label>recall_ID:
      <input type="text" name="recall_ID" value="<?php echo $recall_ID; ?>" />
      <?php
        if ($err && empty($recall_ID)) {
          echo "<label class='errlabel'>Please enter a valid recall_ID.</label>";
        }
      ?>
    </label>
    <br />
    <label>recall_Number:
      <input type="text" name="recall_Number" value="<?php echo $recall_Number; ?>" />
      <?php
        if ($err && empty($recall_Number)) {
          echo "<label class='errlabel'>Please enter a valid recall_Number.</label>";
        }
      ?>
    </label>
    <br />

    <label>recall_date:
      <input type="date" name="recall_date" value="<?php echo date('Y-m-d'); ?>"min="<?php echo date('Y-m-d'); ?>" max="2100-12-31"/>
      <?php
        if ($err && empty($recall_date)) {
          echo "<label class='errlabel'>Please enter a recall_date.</label>";
        }
      ?>
    </label>
    <br />

    <label>recall_Description:
      <textarea rows=5 style='width:500px' name='recall_Description'><?php echo $recall_Description; ?> </textarea>
      <?php
        if ($err && empty($recall_Description)) {
          echo "<label class='errlabel'>Please enter a proper recall_Description.</label>";
        }
      ?>
    </label>
    <br />
    <label>recall_title:
      <textarea rows=5 style='width:500px' name='recall_title'><?php echo $recall_title; ?> </textarea>
      <?php
        if ($err && empty($recall_title)) {
          echo "<label class='errlabel'>Please enter a proper recall_title.</label>";
        }
      ?>
    </label>
    <br />

    <label>recall_Last_Publish_Date:
      <input type="date" name="recall_Last_Publish_Date" value="<?php echo $recall_Last_Publish_Date; ?>" />
      <?php
        if ($err && empty($recall_Last_Publish_Date)) {
          echo "<label class='errlabel'>Please enter a Location.</label>";
        }
      ?>
    </label>
    <br />
    <label>recall_Product_Name:
      <textarea rows=5 style='width:500px' name='recall_Product_Name'><?php echo $recall_Product_Name; ?>" </textarea>
      <?php
        if ($err && empty($recall_Product_Name)) {
          echo "<label class='errlabel'>Please enter a valid recall_Product_Name.</label>";
        }
      ?>
    </label>
    <br />
    <label>recall_URL:
      <textarea rows=5 style='width:500px' name='recall_URL'> <?php echo $recall_URL; ?> </textarea>
      <?php
        if ($err && empty($recall_URL)) {
          echo "<label class='errlabel'>Please enter a valid recall_URL.</label>";
        }
      ?>
    </label>
    <br />
    <input type='submit' name='submit' value='save edited recall' />
  </form>

</div>
<p style='margin-left: auto; display: block; margin-right: auto;'>
  <a style="background-color:white;" href="logout.php">Click here to log out</a>
</p>
</body>
