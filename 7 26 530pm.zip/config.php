<?php
  define('DB_HOST', "localhost");   //localhost:8080
  define('DB_USER', "root");
  define('DB_PASS', "");
  define('DB_NAME', "cpsc");
 ?>
